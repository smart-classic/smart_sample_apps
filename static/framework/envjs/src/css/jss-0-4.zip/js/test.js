var a =function() {
	var styles = $('style');
	//$('body').prepend(styles.get(0).innerHTML);
}